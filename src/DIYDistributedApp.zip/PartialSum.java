import java.io.Serializable;

public class PartialSum implements Serializable
{

	private static final long serialVersionUID = 1L;
	public double sum;
	
	public PartialSum(double s)
	{
		sum = s;
	}
	
}
